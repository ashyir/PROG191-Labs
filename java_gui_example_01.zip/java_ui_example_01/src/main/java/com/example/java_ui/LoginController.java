package com.example.java_ui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class LoginController {
    List<Account> Accounts;

    @FXML
    TextField usernameTextField;
    @FXML
    PasswordField passwordTextField;
    @FXML
    Button loginButton;
    @FXML
    Label notification;

    public LoginController() {
        this.Accounts = new ArrayList<Account>();
    }

    @FXML
    protected void loginButtonClick() {
        var username = usernameTextField.getText();
        var password = passwordTextField.getText();

        notification.setTextFill(Color.RED);

        if (username.isBlank()) {
            notification.setText("Username is blank.");
            usernameTextField.requestFocus();
            return;
        }

        if (password.isBlank()) {
            notification.setText("Password is blank.");
            passwordTextField.requestFocus();
            return;
        }

        for (var account : this.Accounts) {
            if (username.equals(account.Username) &&
                    password.equals(account.Password))
            {
                notification.setText("Login successfully.");
                notification.setTextFill(Color.GREEN);

                usernameTextField.setText("");
                passwordTextField.setText("");

                usernameTextField.requestFocus();

                return;
            }
        }

        notification.setText("Login failed.");
        usernameTextField.requestFocus();
    }

    @FXML
    protected void registerButtonClick() {
        var username = usernameTextField.getText();
        var password = passwordTextField.getText();

        notification.setTextFill(Color.RED);

        if (username.isBlank()) {
            notification.setText("Username is blank.");
            usernameTextField.requestFocus();
            return;
        }

        if (password.isBlank()) {
            notification.setText("Password is blank.");
            passwordTextField.requestFocus();
            return;
        }

        for (var account : this.Accounts) {
            if (username.equals(account.Username)) {
                notification.setText("Username exists.");
                usernameTextField.requestFocus();
                return;
            }
        }

        Account account = new Account(username, password);
        this.Accounts.add(account);

        notification.setText("Register successfully.");
        notification.setTextFill(Color.GREEN);

        usernameTextField.setText("");
        passwordTextField.setText("");

        usernameTextField.requestFocus();
    }
}

class Account {
    public String Username;
    public String Password;

    public Account (String username, String password) {
        this.Username = username;
        this.Password = password;
    }
}